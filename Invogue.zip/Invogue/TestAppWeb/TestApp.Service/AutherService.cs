﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Data.Infrastructure;
using TestApp.Data.Repository;
using TestApp.Model.Models;

namespace TestApp.Service
{
    public interface IAutherService
    {
        bool CreateAuther(Auther auther);
        bool UpdateAuther(Auther auther);
        bool DeleteAuther(int id);
        Auther GetAuther(int id);
        IEnumerable<Auther> GetAllAuther();
        void SaveRecord();
    }
    public class AutherService : IAutherService
    {
        private readonly IAutherRepository autherRepository;
        private readonly IUnitOfWork unitOfWork;

        public AutherService(IAutherRepository autherRepository, IUnitOfWork unitOfWork)
        {
            this.autherRepository = autherRepository;
            this.unitOfWork = unitOfWork;
        }


        public bool CreateAuther(Auther auther)
        {
            bool isSuccess = true;
            try
            {
                autherRepository.Add(auther);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool UpdateAuther(Auther auther)
        {
            bool isSuccess = true;
            try
            {
                autherRepository.Update(auther);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool DeleteAuther(int id)
        {
            bool isSuccess = true;
            var auther = autherRepository.GetById(id);
            try
            {
                autherRepository.Delete(auther);
                SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public Auther GetAuther(int id)
        {
            return autherRepository.GetById(id);
        }

        public IEnumerable<Auther> GetAllAuther()
        {
            return autherRepository.GetAll();
        }

        public void SaveRecord()
        {
            unitOfWork.Commit();
        }
    }
}
