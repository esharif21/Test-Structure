﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Data.Infrastructure;
using TestApp.Data.Repository;
using TestApp.Model.Models;

namespace TestApp.Service
{
    public interface IBookIssueDetailService
    {
        bool CreateBookIssueDetail(BookIssueDetail bookIssueDetail);
        bool UpdateBookIssueDetail(BookIssueDetail bookIssueDetail);
        bool DeleteBookIssueDetail(Guid id);
        BookIssueDetail GetBookIssueDetail(Guid id);
        IEnumerable<BookIssueDetail> GetAllBookIssueDetail();
        void SaveRecord();
    }
    public class BookIssueDetailService : IBookIssueDetailService
    {
        private readonly IBookIssueDetailRepository bookIssueDetailRepository;
        private readonly IUnitOfWork unitOfWork;

        public BookIssueDetailService(IBookIssueDetailRepository bookIssueDetailRepository, IUnitOfWork unitOfWork)
        {
            this.bookIssueDetailRepository = bookIssueDetailRepository;
            this.unitOfWork = unitOfWork;
        }


        public bool CreateBookIssueDetail(BookIssueDetail bookIssueDetail)
        {
            bool isSuccess = true;
            try
            {
                bookIssueDetailRepository.Add(bookIssueDetail);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool UpdateBookIssueDetail(BookIssueDetail bookIssueDetail)
        {
            bool isSuccess = true;
            try
            {
                bookIssueDetailRepository.Update(bookIssueDetail);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool DeleteBookIssueDetail(Guid id)
        {
            bool isSuccess = true;
            var bookIssueDetail = bookIssueDetailRepository.GetById(id);
            try
            {
                bookIssueDetailRepository.Delete(bookIssueDetail);
                SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public BookIssueDetail GetBookIssueDetail(Guid id)
        {
            return bookIssueDetailRepository.GetById(id);
        }

        public IEnumerable<BookIssueDetail> GetAllBookIssueDetail()
        {
            return bookIssueDetailRepository.GetAll();
        }

        public void SaveRecord()
        {
            unitOfWork.Commit();
        }
    }
}
