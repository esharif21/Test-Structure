﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Data.Infrastructure;
using TestApp.Data.Repository;
using TestApp.Model.Models;

namespace TestApp.Service
{
    public interface IBookIssueService
    {
        bool CreateBookIssue(BookIssue bookIssue);
        bool UpdateBookIssue(BookIssue bookIssue);
        bool DeleteBookIssue(Guid id);
        BookIssue GetBookIssue(Guid id);
        IEnumerable<BookIssue> GetAllBookIssue();
        IEnumerable<BookIssue> GetAllBookIssueByStudentIdIssueDate(long? studentId, DateTime? issueDate);
        void SaveRecord();
    }
    public class BookIssueService : IBookIssueService
    {
        private readonly IBookIssueRepository bookIssueRepository;
        private readonly IBookRepository bookRepository;
        private readonly IUnitOfWork unitOfWork;

        public BookIssueService(IBookIssueRepository bookIssueRepository, IBookRepository bookRepository, IUnitOfWork unitOfWork)
        {
            this.bookIssueRepository = bookIssueRepository;
            this.bookRepository = bookRepository;
            this.unitOfWork = unitOfWork;
        }


        public bool CreateBookIssue(BookIssue bookIssue)
        {
            bool isSuccess = true;
            try
            {
                bookIssueRepository.Add(bookIssue);
                this.SaveRecord();

                foreach (var bookIssueDet in bookIssue.BookIssueDetails)
                {
                    var book = bookRepository.GetById(bookIssueDet.BookId);
                    book.IsIssued = true;
                    bookRepository.Update(book);
                }
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool UpdateBookIssue(BookIssue bookIssue)
        {
            bool isSuccess = true;
            try
            {
                bookIssueRepository.Update(bookIssue);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool DeleteBookIssue(Guid id)
        {
            bool isSuccess = true;
            var bookIssue = bookIssueRepository.GetById(id);
            try
            {
                foreach (var aBookIssueDet in bookIssue.BookIssueDetails)
                {
                    var book = aBookIssueDet.Book;
                    book.IsIssued = false;
                    bookRepository.Update(book);
                }
                bookIssueRepository.Delete(bookIssue);
                SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public BookIssue GetBookIssue(Guid id)
        {
            return bookIssueRepository.GetById(id);
        }

        public IEnumerable<BookIssue> GetAllBookIssue()
        {
            return bookIssueRepository.GetAll();
        }

        public IEnumerable<BookIssue> GetAllBookIssueByStudentIdIssueDate(long? studentId, DateTime? issueDate)
        {
            return bookIssueRepository.GetMany(x => (x.StudentId == studentId || studentId == null) /*&& (EntityFunctions.TruncateTime(x.IssueDate) == issueDate.Value.Date || issueDate == null)*/);
        }

        public void SaveRecord()
        {
            unitOfWork.Commit();
        }
    }
}
