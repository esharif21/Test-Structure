﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Data.Infrastructure;
using TestApp.Data.Repository;
using TestApp.Model.Models;

namespace TestApp.Service
{
    public interface IBookService
    {
        bool CreateBook(Book book);
        bool UpdateBook(Book book);
        bool DeleteBook(long id);
        Book GetBook(long id);
        string GetBookStatus(long id);
        IEnumerable<Book> GetAllBook();
        IEnumerable<Book> GetBooksByTitleStatus(string title, bool? isIssued);

        void SaveRecord();
    }
    public class BookService : IBookService
    {
        private readonly IBookRepository bookRepository;
        private readonly IUnitOfWork unitOfWork;

        public BookService(IBookRepository bookRepository, IUnitOfWork unitOfWork)
        {
            this.bookRepository = bookRepository;
            this.unitOfWork = unitOfWork;
        }


        public bool CreateBook(Book book)
        {
            bool isSuccess = true;
            try
            {
                bookRepository.Add(book);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool UpdateBook(Book book)
        {
            bool isSuccess = true;
            try
            {
                bookRepository.Update(book);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool DeleteBook(long id)
        {
            bool isSuccess = true;
            var book = bookRepository.GetById(id);
            try
            {
                bookRepository.Delete(book);
                SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public Book GetBook(long id)
        {
            return bookRepository.GetById(id);
        }

        public string GetBookStatus(long id)
        {
            var book = bookRepository.Get(x => x.IsIssued == true && x.Id == id);
            if (book == null)
                return null;
            var bookIssue = book.BookIssueDetails.First().BookIssue;
            var message = "Book '" + book.Title + "' already issued to student '" + bookIssue.Student.Name + "' on " + bookIssue.IssueDate.ToLocalTime().ToString("dd-MM-yyyy");
            return message;
        }

        public IEnumerable<Book> GetAllBook()
        {
            return bookRepository.GetAll();
        }

        public IEnumerable<Book> GetBooksByTitleStatus(string title, bool? isIssued)
        {
            return bookRepository.GetMany(x => (x.Title.ToLower().Contains(title.ToLower()) || title == null || title == "") && (x.IsIssued == isIssued || isIssued == null));
        }

        public void SaveRecord()
        {
            unitOfWork.Commit();
        }
    }
}
