﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Data.Infrastructure;
using TestApp.Data.Repository;
using TestApp.Model.Models;

namespace TestApp.Service
{
    public interface IStudentService
    {
        bool CreateStudent(Student student);
        bool UpdateStudent(Student student);
        bool DeleteStudent(long id);
        Student GetStudent(long id);
        IEnumerable<Student> GetAllStudent();
        void SaveRecord();
    }
    public class StudentService : IStudentService
    {
        private readonly IStudentRepository studentRepository;
        private readonly IUnitOfWork unitOfWork;

        public StudentService(IStudentRepository studentRepository, IUnitOfWork unitOfWork)
        {
            this.studentRepository = studentRepository;
            this.unitOfWork = unitOfWork;
        }


        public bool CreateStudent(Student student)
        {
            bool isSuccess = true;
            try
            {
                studentRepository.Add(student);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool UpdateStudent(Student student)
        {
            bool isSuccess = true;
            try
            {
                studentRepository.Update(student);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool DeleteStudent(long id)
        {
            bool isSuccess = true;
            var student = studentRepository.GetById(id);
            try
            {
                studentRepository.Delete(student);
                SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public Student GetStudent(long id)
        {
            return studentRepository.GetById(id);
        }

        public IEnumerable<Student> GetAllStudent()
        {
            return studentRepository.GetAll();
        }

        public void SaveRecord()
        {
            unitOfWork.Commit();
        }
    }
}
