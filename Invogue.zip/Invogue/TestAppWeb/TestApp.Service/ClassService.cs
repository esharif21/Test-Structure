﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TestApp.Data.Infrastructure;
using TestApp.Data.Repository;
using TestApp.Model.Models;

namespace TestApp.Service
{
    public interface IClassService
    {
        bool CreateClass(Class aClass);
        bool UpdateClass(Class aClass);
        bool DeleteClass(int id);
        Class GetClass(int id);
        IEnumerable<Class> GetAllClass();
        void SaveRecord();
    }
    public class ClassService : IClassService
    {
        private readonly IClassRepository aClassRepository;
        private readonly IUnitOfWork unitOfWork;

        public ClassService(IClassRepository aClassRepository, IUnitOfWork unitOfWork)
        {
            this.aClassRepository = aClassRepository;
            this.unitOfWork = unitOfWork;
        }


        public bool CreateClass(Class aClass)
        {
            bool isSuccess = true;
            try
            {
                aClassRepository.Add(aClass);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool UpdateClass(Class aClass)
        {
            bool isSuccess = true;
            try
            {
                aClassRepository.Update(aClass);
                this.SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public bool DeleteClass(int id)
        {
            bool isSuccess = true;
            var aClass = aClassRepository.GetById(id);
            try
            {
                aClassRepository.Delete(aClass);
                SaveRecord();
            }
            catch
            {
                isSuccess = false;
            }
            return isSuccess;
        }

        public Class GetClass(int id)
        {
            return aClassRepository.GetById(id);
        }

        public IEnumerable<Class> GetAllClass()
        {
            return aClassRepository.GetAll();
        }

        public void SaveRecord()
        {
            unitOfWork.Commit();
        }
    }
}
