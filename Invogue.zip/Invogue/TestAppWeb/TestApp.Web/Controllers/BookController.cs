﻿using TestApp.Model.Models;
using TestApp.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Linq.Dynamic;

namespace TestApp.Web.Controllers
{
    public class BookController : Controller
    {
        public readonly IBookService bookService;

        public BookController(IBookService bookService)
        {
            this.bookService = bookService;
        }

        // GET: /Book/
        public ActionResult Index()
        {
            return View("Book");
        }

        public ActionResult Book()
        {
            return View();
        }

        [HttpPost]
        public JsonResult CreateBook(Book book)
        {
            var isSuccess = false;
            var message = string.Empty;
            var isNew = book.Id == 0 ? true : false;

            if (isNew)
            {
                if (this.bookService.CreateBook(book))
                {
                    isSuccess = true;
                    message = "Book saved successfully!";
                }
                else
                {
                    message = "Book could not saved!";
                }
            }
            else
            {
                var bookObj = this.bookService.GetBook(book.Id);
                if (bookObj != null)
                {
                    bookObj.BookID = book.BookID;
                    bookObj.Title = book.Title;
                    bookObj.AutherId = book.AutherId;
                    bookObj.Price = book.Price;
                    bookObj.IsIssued = book.IsIssued;

                    if (this.bookService.UpdateBook(bookObj))
                    {
                        isSuccess = true;
                        message = "Book updated successfully!";
                    }
                    else
                    {
                        message = "Book could not updated!";
                    }
                }
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message,
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult DeleteBook(Book book)
        {
            var isSuccess = true;
            var message = string.Empty;
            isSuccess = this.bookService.DeleteBook(book.Id);
            if (isSuccess)
            {
                message = "Book deleted successfully!";
            }
            else
            {
                message = "Book can't be deleted!";
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetBookList()
        {
            var bookListObj = this.bookService.GetAllBook();
            /*List<BookViewModel> bookVMList = new List<BookViewModel>();
            foreach (var book in bookListObj)
            {
                BookViewModel bookTemp = new BookViewModel();

                bookTemp.Id = book.Id;
                bookTemp.Name = book.Name;

                bookVMList.Add(bookTemp);
            }*/
            return Json(bookListObj.Select(x => new BookViewModel { Id = x.Id, BookID = x.BookID, AutherId = x.AutherId, AutherName = x.AutherId != null ? x.Auther.Name : "", IsIssued = x.IsIssued, Price = x.Price, Title = x.Title }).ToList(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetBookListWithPaging(int page = 1, int itemsPerPage = 1, string sortBy = "Title", bool reverse = true, string title = null, bool? isIssued = null)
        {
            IEnumerable<Book> bookList = null;

            bookList = this.bookService.GetBooksByTitleStatus(title, isIssued);

            bookList = bookList.OrderBy(sortBy + (reverse ? " descending" : ""));

            // paging
            var booksIssuedPaged = bookList.Skip((page - 1) * itemsPerPage).Take(itemsPerPage);

            List<BookViewModel> bookVMList = null;
            int recordCount = 0;
            if (booksIssuedPaged != null)
            {
                recordCount = bookList.Count();
                bookVMList = new List<BookViewModel>();
                foreach (var book in booksIssuedPaged)
                {
                    BookViewModel bookTemp = new BookViewModel();

                    bookTemp.Id = book.Id;
                    bookTemp.BookID = book.BookID;
                    bookTemp.AutherId = book.AutherId;
                    bookTemp.AutherName = book.AutherId != null ? book.Auther.Name : "";
                    bookTemp.IsIssued = book.IsIssued;
                    bookTemp.Price = book.Price;
                    bookTemp.Title = book.Title;

                    bookVMList.Add(bookTemp);
                }
                return Json(new { data = bookVMList, count = recordCount }, JsonRequestBehavior.AllowGet);
            }
            return null;
        }

        public JsonResult GetBookStatus(long id)
        {
            return Json(new
            {
                message = bookService.GetBookStatus(id)
            }, JsonRequestBehavior.AllowGet);
        }
    }

    public class BookViewModel
    {
        public long Id { get; set; }
        public string BookID { get; set; }
        public string Title { get; set; }
        public Nullable<int> AutherId { get; set; }
        public string AutherName { get; set; }
        public Nullable<double> Price { get; set; }
        public Nullable<bool> IsIssued { get; set; }
    }
}