﻿using TestApp.Model.Models;
using TestApp.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TestApp.Web.Controllers
{
    public class StudentController : Controller
    {
        public readonly IStudentService studentService;

        public StudentController(IStudentService studentService)
        {
            this.studentService = studentService;
        }

        // GET: /Student/
        public ActionResult Index()
        {
            return View("Student");
        }

        public ActionResult Student()
        {
            return View();
        }

        [HttpPost]
        public JsonResult CreateStudent(Student student)
        {
            var isSuccess = false;
            var message = string.Empty;
            var isNew = student.Id == 0 ? true : false;

            if (isNew)
            {
                if (this.studentService.CreateStudent(student))
                {
                    isSuccess = true;
                    message = "Student saved successfully!";
                }
                else
                {
                    message = "Student could not saved!";
                }
            }
            else
            {
                var studentObj = this.studentService.GetStudent(student.Id);
                if (studentObj != null)
                {
                    studentObj.StudentID = student.StudentID;
                    studentObj.Name = student.Name;
                    studentObj.ClassId = student.ClassId;

                    if (this.studentService.UpdateStudent(studentObj))
                    {
                        isSuccess = true;
                        message = "Student updated successfully!";
                    }
                    else
                    {
                        message = "Student could not updated!";
                    }
                }
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message,
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult DeleteStudent(Student student)
        {
            var isSuccess = true;
            var message = string.Empty;
            isSuccess = this.studentService.DeleteStudent(student.Id);
            if (isSuccess)
            {
                message = "Student deleted successfully!";
            }
            else
            {
                message = "Student can't be deleted!";
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetStudentList()
        {
            var studentListObj = this.studentService.GetAllStudent();
            /*List<StudentViewModel> studentVMList = new List<StudentViewModel>();
            foreach (var student in studentListObj)
            {
                StudentViewModel studentTemp = new StudentViewModel();

                studentTemp.Id = student.Id;
                studentTemp.Name = student.Name;

                studentVMList.Add(studentTemp);
            }*/
            return Json(studentListObj.Select(x => new StudentViewModel { Id = x.Id, Name = x.Name, StudentID = x.StudentID, ClassId = x.ClassId, ClassName = x.ClassId != null ? x.Class.Name : "" }).ToList(), JsonRequestBehavior.AllowGet);
        }
    }

    public class StudentViewModel
    {
        public long Id { get; set; }
        public string StudentID { get; set; }
        public string Name { get; set; }
        public Nullable<int> ClassId { get; set; }
        public string ClassName { get; set; }
    }
}