﻿using TestApp.Model.Models;
using TestApp.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TestApp.Web.Controllers
{
    public class AutherController : Controller
    {
        public readonly IAutherService autherService;

        public AutherController(IAutherService autherService)
        {
            this.autherService = autherService;
        }

        // GET: /Auther/
        public ActionResult Index()
        {
            return View("Auther");
        }

        public ActionResult Auther()
        {
            return View();
        }

        [HttpPost]
        public JsonResult CreateAuther(Auther auther)
        {
            var isSuccess = false;
            var message = string.Empty;
            var isNew = auther.Id == 0 ? true : false;

            if (isNew)
            {
                if (this.autherService.CreateAuther(auther))
                {
                    isSuccess = true;
                    message = "Auther saved successfully!";
                }
                else
                {
                    message = "Auther could not saved!";
                }
            }
            else
            {
                var autherObj = this.autherService.GetAuther(auther.Id);
                if (autherObj != null)
                {
                    autherObj.Name = auther.Name;
                    if(this.autherService.UpdateAuther(autherObj))
                    {
                        isSuccess = true;
                        message = "Auther updated successfully!";
                    }
                    else
                    {
                        message = "Auther could not updated!";
                    }
                }
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message,
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult DeleteAuther(Auther auther)
        {
            var isSuccess = true;
            var message = string.Empty;
            isSuccess = this.autherService.DeleteAuther(auther.Id);
            if (isSuccess)
            {
                message = "Auther deleted successfully!";
            }
            else
            {
                message = "Auther can't be deleted!";
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetAutherList()
        {
            var autherListObj = this.autherService.GetAllAuther();
            /*List<AutherViewModel> autherVMList = new List<AutherViewModel>();
            foreach (var auther in autherListObj)
            {
                AutherViewModel autherTemp = new AutherViewModel();

                autherTemp.Id = auther.Id;
                autherTemp.Name = auther.Name;

                autherVMList.Add(autherTemp);
            }*/
            return Json(autherListObj.Select(x=> new AutherViewModel{Id=x.Id, Name = x.Name}).ToList(), JsonRequestBehavior.AllowGet);
        }
    }

    public class AutherViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}