﻿using TestApp.Model.Models;
using TestApp.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace TestApp.Web.Controllers
{
    public class ClassController : Controller
    {
        public readonly IClassService aClassService;

        public ClassController(IClassService aClassService)
        {
            this.aClassService = aClassService;
        }

        // GET: /Class/
        public ActionResult Index()
        {
            return View("Class");
        }

        public ActionResult Class()
        {
            return View();
        }

        [HttpPost]
        public JsonResult CreateClass(Class aClass)
        {
            var isSuccess = false;
            var message = string.Empty;
            var isNew = aClass.Id == 0 ? true : false;

            if (isNew)
            {
                if (this.aClassService.CreateClass(aClass))
                {
                    isSuccess = true;
                    message = "Class saved successfully!";
                }
                else
                {
                    message = "Class could not saved!";
                }
            }
            else
            {
                var aClassObj = this.aClassService.GetClass(aClass.Id);
                if (aClassObj != null)
                {
                    aClassObj.Name = aClass.Name;
                    if(this.aClassService.UpdateClass(aClassObj))
                    {
                        isSuccess = true;
                        message = "Class updated successfully!";
                    }
                    else
                    {
                        message = "Class could not updated!";
                    }
                }
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message,
            }, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult DeleteClass(Class aClass)
        {
            var isSuccess = true;
            var message = string.Empty;
            isSuccess = this.aClassService.DeleteClass(aClass.Id);
            if (isSuccess)
            {
                message = "Class deleted successfully!";
            }
            else
            {
                message = "Class can't be deleted!";
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetClassList()
        {
            var aClassListObj = this.aClassService.GetAllClass();
            /*List<ClassViewModel> aClassVMList = new List<ClassViewModel>();
            foreach (var aClass in aClassListObj)
            {
                ClassViewModel aClassTemp = new ClassViewModel();

                aClassTemp.Id = aClass.Id;
                aClassTemp.Name = aClass.Name;

                aClassVMList.Add(aClassTemp);
            }*/
            return Json(aClassListObj.Select(x=> new ClassViewModel{Id=x.Id, Name = x.Name}).ToList(), JsonRequestBehavior.AllowGet);
        }
    }

    public class ClassViewModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}