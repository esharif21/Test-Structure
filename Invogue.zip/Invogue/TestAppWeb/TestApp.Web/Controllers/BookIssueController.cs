﻿using TestApp.Model.Models;
using TestApp.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Linq.Dynamic;

namespace TestApp.Web.Controllers
{
    public class BookIssueController : Controller
    {
        public readonly IBookIssueService bookIssueService;

        public BookIssueController(IBookIssueService bookIssueService)
        {
            this.bookIssueService = bookIssueService;
        }

        // GET: /BookIssue/
        public ActionResult Index()
        {
            return View("BookIssue");
        }

        public ActionResult BookIssue()
        {
            return View();
        }

        [HttpPost]
        public JsonResult CreateBookIssue(BookIssue bookIssue)
        {
            var isSuccess = false;
            var message = string.Empty;
            var isNew = bookIssue.Id == Guid.Empty ? true : false;

            if (isNew)
            {
                bookIssue.Id = Guid.NewGuid();
                if (bookIssue.BookIssueDetails != null)
                {
                    foreach (var bookIssueDetail in bookIssue.BookIssueDetails)
                    {
                        bookIssueDetail.Id = Guid.NewGuid();
                    }
                }
                if (this.bookIssueService.CreateBookIssue(bookIssue))
                {
                    isSuccess = true;
                    message = "BookIssue saved successfully!";
                }
                else
                {
                    message = "BookIssue could not saved!";
                }
            }
            else
            {
                // update not done
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message,
            }, JsonRequestBehavior.AllowGet);
        }

        public JsonResult DeleteBookIssue(Guid id)
        {
            var isSuccess = true;
            var message = string.Empty;
            isSuccess = this.bookIssueService.DeleteBookIssue(id);
            if (isSuccess)
            {
                message = "BookIssue deleted successfully!";
            }
            else
            {
                message = "BookIssue can't be deleted!";
            }
            return Json(new
            {
                isSuccess = isSuccess,
                message = message
            }, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GetBookIssueList(int page = 1, int itemsPerPage = 1, string sortBy = "IssueDate", bool reverse = true, long? studentId = null, DateTime? issueDate = null)
        {
            IEnumerable<BookIssue> bookIssueList = null;

            bookIssueList = this.bookIssueService.GetAllBookIssueByStudentIdIssueDate(studentId, issueDate);

            bookIssueList = bookIssueList.OrderBy(sortBy + (reverse ? " descending" : ""));

            // paging
            var booksIssuedPaged = bookIssueList.Skip((page - 1) * itemsPerPage).Take(itemsPerPage);

            List<BookIssueViewModel> bookIssueVMList = null;
            int recordCount = 0;
            if (booksIssuedPaged != null)
            {
                recordCount = bookIssueList.Count();
                bookIssueVMList = new List<BookIssueViewModel>();
                foreach (var bookIssue in booksIssuedPaged)
                {
                    BookIssueViewModel bookIssueTemp = new BookIssueViewModel();

                    bookIssueTemp.Id = bookIssue.Id;
                    bookIssueTemp.IssueDate = bookIssue.IssueDate.ToLocalTime().ToString("dd-MMM-yyyy");
                    bookIssueTemp.StudentId = bookIssue.StudentId;
                    bookIssueTemp.StudentID = bookIssue.Student.StudentID;
                    bookIssueTemp.TotalIssuedBooks = bookIssue.TotalIssuedBooks;

                    if (bookIssue.BookIssueDetails.Count() > 0)
                    {
                        int issueDetailCount = 0;
                        List<BookIssueDetailViewModel> bookIssueDetailVMList = new List<BookIssueDetailViewModel>();
                        foreach (var bookIssueDet in bookIssue.BookIssueDetails)
                        {
                            BookIssueDetailViewModel bookIssueDetailTtemp = new BookIssueDetailViewModel();
                            bookIssueDetailTtemp.Id = bookIssueDet.Id;
                            bookIssueDetailTtemp.BookIssueId = bookIssueDet.BookIssueId;
                            bookIssueDetailTtemp.BookId = bookIssueDet.BookId;
                            bookIssueDetailTtemp.BookTitle = bookIssueDet.Book.Title;
                            bookIssueDetailTtemp.ReturnDate = bookIssueDet.ReturnDate != null ? bookIssueDet.ReturnDate.Value.ToLocalTime().ToString("dd-MMM-yyyy") : "";
                            
                            bookIssueDetailVMList.Add(bookIssueDetailTtemp);
                        }
                        bookIssueTemp.BookIssueDetails = bookIssueDetailVMList;
                    }

                    bookIssueVMList.Add(bookIssueTemp);
                }
                return Json(new { data = bookIssueVMList, count = recordCount }, JsonRequestBehavior.AllowGet);
            }
            return null;
        }
    }

    public class BookIssueViewModel
    {
        public BookIssueViewModel()
        {
            this.BookIssueDetails = new List<BookIssueDetailViewModel>();
        }

        public System.Guid Id { get; set; }
        public long StudentId { get; set; }
        public string IssueDate { get; set; }
        public int TotalIssuedBooks { get; set; }
        public ICollection<BookIssueDetailViewModel> BookIssueDetails { get; set; }
        public string StudentID { get; set; }
    }

    public class BookIssueDetailViewModel
    {
        public System.Guid Id { get; set; }
        public Nullable<System.Guid> BookIssueId { get; set; }
        public Nullable<long> BookId { get; set; }
        public string ReturnDate { get; set; }
        public string BookTitle { get; set; }
    }
}