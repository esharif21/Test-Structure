﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FisheriesManagement.Web.Models
{
    public enum EnumUnitModel : int
    {
        Gram = 1,
        Kilo_Gram,
        Pound,
        Piece,
    }
}