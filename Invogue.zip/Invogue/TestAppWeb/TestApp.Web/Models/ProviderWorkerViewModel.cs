﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;


namespace FisheriesManagement.Web.Models
{
    [DataContract]
    public class ProviderWorkerViewModel
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public int ServiceProviderId { get; set; }
        [DataMember]
        public string ServiceProviderName { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        [DataMember]
        public string LastName { get; set; }
        [DataMember]
        public string Title { get; set; }
        [DataMember]
        public string EmailAddress { get; set; }
        [DataMember]
        public string PhoneNumber { get; set; }
        [DataMember]
        public int UserId { get; set; }
    }
}