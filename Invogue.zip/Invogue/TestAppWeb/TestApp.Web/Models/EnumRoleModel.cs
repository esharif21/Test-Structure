﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PC.Web.Models
{
    public enum EnumRoleModel : int
    {
        Super_Admin = 1,
        Director,
        Manager,
        Operator,
    }
}