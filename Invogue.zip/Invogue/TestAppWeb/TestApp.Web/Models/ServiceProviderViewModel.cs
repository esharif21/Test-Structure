﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;


namespace FisheriesManagement.Web.Models
{
    [DataContract]
    public class ServiceProviderViewModel
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string CompanyName { get; set; }
        [DataMember]
        public string EmailAddress { get; set; }
        [DataMember]
        public string TelephoneNumber { get; set; }
        [DataMember]
        public string CVRNumber { get; set; }
        [DataMember]
        public string EANNumber { get; set; }
        [DataMember]
        public System.DateTime LastUpdated { get; set; }
        [DataMember]
        public string Address { get; set; }
        [DataMember]
        public string Street { get; set; }
        [DataMember]
        public string PostalCode { get; set; }
        [DataMember]
        public int CityId { get; set; }
        [DataMember]
        public int CountryId { get; set; }
        [DataMember]
        public string CityName { get; set; }
        [DataMember]
        public string CountryName { get; set; }
    }
}