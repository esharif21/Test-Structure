﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;


namespace FisheriesManagement.Web.Models
{
    [DataContract]
    public class ServicePersonViewModel
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string FirstName { get; set; }
        public string LastName { get; set; }
        [DataMember]
        public bool IsMale { get; set; }
        [DataMember]
        public string Title { get; set; }
        [DataMember]
        public string EmailAddress { get; set; }
        [DataMember]
        public string PhoneNumber { get; set; }
        [DataMember]
        public string CPRNumber { get; set; }
        [DataMember]
        public string CVRNumber { get; set; }
        [DataMember]
        public byte[] ApplicationForm { get; set; }
        [DataMember]
        public string FileName { get; set; }
        [DataMember]
        public string Street { get; set; }
        [DataMember]
        public string PostalCode { get; set; }
        [DataMember]
        public int CityId { get; set; }
        [DataMember]
        public int CountryId { get; set; }
        [DataMember]
        public string ServicePersonNr { get; set; }
        [DataMember]
        public int UserId { get; set; }
        [DataMember]
        public string CityName { get; set; }
        [DataMember]
        public string CountryName { get; set; }
    }
}