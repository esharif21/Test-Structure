using System;
using System.Collections.Generic;

namespace TestApp.Model.Models
{
    public partial class Book
    {
        public Book()
        {
            this.BookIssueDetails = new List<BookIssueDetail>();
        }

        public long Id { get; set; }
        public string BookID { get; set; }
        public string Title { get; set; }
        public Nullable<int> AutherId { get; set; }
        public Nullable<double> Price { get; set; }
        public Nullable<bool> IsIssued { get; set; }
        public virtual Auther Auther { get; set; }
        public virtual ICollection<BookIssueDetail> BookIssueDetails { get; set; }
    }
}
