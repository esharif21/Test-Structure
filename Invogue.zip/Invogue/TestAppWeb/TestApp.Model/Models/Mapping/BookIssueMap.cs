using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace TestApp.Model.Models.Mapping
{
    public class BookIssueMap : EntityTypeConfiguration<BookIssue>
    {
        public BookIssueMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            // Table & Column Mappings
            this.ToTable("BookIssue");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.StudentId).HasColumnName("StudentId");
            this.Property(t => t.IssueDate).HasColumnName("IssueDate");
            this.Property(t => t.TotalIssuedBooks).HasColumnName("TotalIssuedBooks");

            // Relationships
            this.HasRequired(t => t.Student)
                .WithMany(t => t.BookIssues)
                .HasForeignKey(d => d.StudentId);

        }
    }
}
