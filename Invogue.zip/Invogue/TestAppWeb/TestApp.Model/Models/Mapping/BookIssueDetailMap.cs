using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace TestApp.Model.Models.Mapping
{
    public class BookIssueDetailMap : EntityTypeConfiguration<BookIssueDetail>
    {
        public BookIssueDetailMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            // Table & Column Mappings
            this.ToTable("BookIssueDetail");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.BookIssueId).HasColumnName("BookIssueId");
            this.Property(t => t.BookId).HasColumnName("BookId");
            this.Property(t => t.ReturnDate).HasColumnName("ReturnDate");

            // Relationships
            this.HasRequired(t => t.Book)
                .WithMany(t => t.BookIssueDetails)
                .HasForeignKey(d => d.BookId);
            this.HasRequired(t => t.BookIssue)
                .WithMany(t => t.BookIssueDetails)
                .HasForeignKey(d => d.BookIssueId);

        }
    }
}
