using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity.ModelConfiguration;

namespace TestApp.Model.Models.Mapping
{
    public class BookMap : EntityTypeConfiguration<Book>
    {
        public BookMap()
        {
            // Primary Key
            this.HasKey(t => t.Id);

            // Properties
            this.Property(t => t.BookID)
                .IsRequired()
                .HasMaxLength(100);

            this.Property(t => t.Title)
                .HasMaxLength(100);

            // Table & Column Mappings
            this.ToTable("Book");
            this.Property(t => t.Id).HasColumnName("Id");
            this.Property(t => t.BookID).HasColumnName("BookID");
            this.Property(t => t.Title).HasColumnName("Title");
            this.Property(t => t.AutherId).HasColumnName("AutherId");
            this.Property(t => t.Price).HasColumnName("Price");
            this.Property(t => t.IsIssued).HasColumnName("IsIssued");

            // Relationships
            this.HasOptional(t => t.Auther)
                .WithMany(t => t.Books)
                .HasForeignKey(d => d.AutherId);

        }
    }
}
