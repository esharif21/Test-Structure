using System;
using System.Collections.Generic;

namespace TestApp.Model.Models
{
    public partial class BookIssueDetail
    {
        public System.Guid Id { get; set; }
        public System.Guid BookIssueId { get; set; }
        public long BookId { get; set; }
        public Nullable<System.DateTime> ReturnDate { get; set; }
        public virtual Book Book { get; set; }
        public virtual BookIssue BookIssue { get; set; }
    }
}
