using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using TestApp.Model.Models.Mapping;

namespace TestApp.Model.Models
{
    public partial class LMS_DbContext : DbContext
    {
        static LMS_DbContext()
        {
            Database.SetInitializer<LMS_DbContext>(null);
        }

        public LMS_DbContext()
            : base("Name=LMS_DbContext")
        {
        }

        public DbSet<Auther> Authers { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<BookIssue> BookIssues { get; set; }
        public DbSet<BookIssueDetail> BookIssueDetails { get; set; }
        public DbSet<Class> Classes { get; set; }
        public DbSet<Student> Students { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new AutherMap());
            modelBuilder.Configurations.Add(new BookMap());
            modelBuilder.Configurations.Add(new BookIssueMap());
            modelBuilder.Configurations.Add(new BookIssueDetailMap());
            modelBuilder.Configurations.Add(new ClassMap());
            modelBuilder.Configurations.Add(new StudentMap());
        }
    }
}
