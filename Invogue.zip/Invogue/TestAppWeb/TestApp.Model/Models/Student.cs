using System;
using System.Collections.Generic;

namespace TestApp.Model.Models
{
    public partial class Student
    {
        public Student()
        {
            this.BookIssues = new List<BookIssue>();
        }

        public long Id { get; set; }
        public string StudentID { get; set; }
        public string Name { get; set; }
        public Nullable<int> ClassId { get; set; }
        public virtual ICollection<BookIssue> BookIssues { get; set; }
        public virtual Class Class { get; set; }
    }
}
