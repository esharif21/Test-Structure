using System;
using System.Collections.Generic;

namespace TestApp.Model.Models
{
    public partial class BookIssue
    {
        public BookIssue()
        {
            this.BookIssueDetails = new List<BookIssueDetail>();
        }

        public System.Guid Id { get; set; }
        public long StudentId { get; set; }
        public System.DateTime IssueDate { get; set; }
        public int TotalIssuedBooks { get; set; }
        public virtual Student Student { get; set; }
        public virtual ICollection<BookIssueDetail> BookIssueDetails { get; set; }
    }
}
