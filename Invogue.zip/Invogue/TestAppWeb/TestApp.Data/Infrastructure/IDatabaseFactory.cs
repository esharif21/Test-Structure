﻿using System;
using TestApp.Data.Models;

namespace TestApp.Data.Infrastructure
{
    public interface IDatabaseFactory : IDisposable
    {
        ApplicationEntities Get();
    }
}
