﻿using Microsoft.AspNet.Identity.EntityFramework;
using TestApp.Model.Models;
using TestApp.Model.Models.Mapping;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Infrastructure;
using System.Data.Entity.ModelConfiguration.Conventions;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp.Data.Models
{
    public class ApplicationEntities : DbContext
    {
        public ApplicationEntities(): base("DBConnection")
        {
            /**
             * It's not necessary to remove the virtual keyword from the navigation properties (which would make lazy loading completely 
             * impossible for the model). It's enough to disable proxy creation (which disables lazy loading as well) for the specific circumstances 
             * where proxies are disturbing, like serialization
             */
            //this.Configuration.ProxyCreationEnabled = false;
        }

        public DbSet<Auther> Authers { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<BookIssue> BookIssues { get; set; }
        public DbSet<BookIssueDetail> BookIssueDetails { get; set; }
        public DbSet<Class> Classes { get; set; }
        public DbSet<Student> Students { get; set; }

        
        public virtual void Commit()
        {
            base.SaveChanges();
        }
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            //modelBuilder.Entity<GroupGoal>()
            //            .HasOptional(e => e.Focus)
            //            .WithMany()
            //            .HasForeignKey(e => e.FocusId)
            //            .WillCascadeOnDelete();

            //modelBuilder.IncludeMetadataInDatabase = false;
            Database.SetInitializer<ApplicationEntities>(null);

            // Configura the model map
            modelBuilder.Configurations.Add(new AutherMap());
            modelBuilder.Configurations.Add(new BookMap());
            modelBuilder.Configurations.Add(new BookIssueMap());
            modelBuilder.Configurations.Add(new BookIssueDetailMap());
            modelBuilder.Configurations.Add(new ClassMap());
            modelBuilder.Configurations.Add(new StudentMap());


            // Remove metadata convention
            modelBuilder.Conventions.Remove<IncludeMetadataConvention>();

            // Remove the pluralization
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }
    }
}
