﻿using TestApp.Data.Infrastructure;
using TestApp.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp.Data.Repository
{
    public class AutherRepository : RepositoryBase<Auther>, IAutherRepository
    {
        public AutherRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

      
    public interface IAutherRepository : IRepository<Auther>
    {
    }
}
