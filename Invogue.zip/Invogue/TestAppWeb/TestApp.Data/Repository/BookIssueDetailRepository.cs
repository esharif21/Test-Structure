﻿using TestApp.Data.Infrastructure;
using TestApp.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp.Data.Repository
{
    public class BookIssueDetailRepository : RepositoryBase<BookIssueDetail>, IBookIssueDetailRepository
    {
        public BookIssueDetailRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

      
    public interface IBookIssueDetailRepository : IRepository<BookIssueDetail>
    {
    }
}
