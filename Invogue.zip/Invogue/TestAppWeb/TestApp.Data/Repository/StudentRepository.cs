﻿using TestApp.Data.Infrastructure;
using TestApp.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp.Data.Repository
{
    public class StudentRepository : RepositoryBase<Student>, IStudentRepository
    {
        public StudentRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

      
    public interface IStudentRepository : IRepository<Student>
    {
    }
}
