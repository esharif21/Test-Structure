﻿using TestApp.Data.Infrastructure;
using TestApp.Model.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestApp.Data.Repository
{
    public class ClassRepository : RepositoryBase<Class>, IClassRepository
    {
        public ClassRepository(IDatabaseFactory databaseFactory)
            : base(databaseFactory)
        {
        }
    }

      
    public interface IClassRepository : IRepository<Class>
    {
    }
}
